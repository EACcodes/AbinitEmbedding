/* Adapted from pcp from SUT, in MPI */ 
#ifdef __MPI
#include "mpi.h" 
#endif
#include <stdio.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include "fpreproc/f77name.h"

#define BUFSIZE    256*1024 
#define CMDSIZE    80 
int F77NAME(portlib_parcopy)(npcopy_comm,myrank,jwrite,cinput,coutput,ctarg)
    int *npcopy_comm;
    int *myrank;
    int *jwrite;
    const char *cinput;
    const char *coutput;
    const char *ctarg;
{ 
    int mystatus, allstatus, done, numread; 
    char controlmsg[80]; 
    int infd, outfd; 
    char buf[BUFSIZE]; 
    
   sprintf( controlmsg, "dummy" );
   if ( *myrank == 0 ){  
     if ( (infd = open( cinput, O_RDONLY ) ) == -1 ) {
       fprintf( stderr, "input file %s does not exist\n", cinput );
       sprintf( controlmsg, "exit" );
#ifdef __MPI
       MPI_Bcast( controlmsg, CMDSIZE, MPI_CHAR, 0, *npcopy_comm );
       MPI_Finalize();
#endif
       return( -1 );
      }
     else {
       fprintf( stderr, "myrank: %d - input file - %s - exists\n", *myrank, cinput );
       sprintf( controlmsg, "ready" );
#ifdef __MPI
       fprintf( stderr, "I, myrank %d, am %s \n", *myrank, controlmsg );
       MPI_Bcast( controlmsg, CMDSIZE, MPI_CHAR, 0, *npcopy_comm );
#endif
      }
   }
   else if (*myrank != 0)  {
#ifdef __MPI
      MPI_Bcast( controlmsg, CMDSIZE, MPI_CHAR, 0, *npcopy_comm );
      fprintf( stderr, "I, myrank %d, am %s \n", *myrank, controlmsg );
#endif
      if ( strcmp( controlmsg, "exit" ) == 0 ) {
#ifdef __MPI
         MPI_Finalize();
#endif
      return( -1 );
      }
   }

    if ( *myrank == 0 )
        sprintf( controlmsg, coutput );
#ifdef __MPI
        MPI_Bcast( controlmsg, CMDSIZE, MPI_CHAR, 0, *npcopy_comm );
#endif
    if ( (outfd = open( controlmsg, O_CREAT|O_WRONLY|O_TRUNC, S_IRWXU ) ) == -1 )
        mystatus = -1;
    else
        mystatus = 0;
#ifdef __MPI
        MPI_Allreduce( &mystatus, &allstatus, 1, MPI_INT, MPI_MIN,
                   *npcopy_comm );
#endif
    if ( allstatus == -1 ) {
        if ( *myrank == 0 )
            fprintf( stderr, "output file %s could not be opened\n",
                     coutput );
#ifdef __MPI
/*       MPI_Finalize(); */
#endif
/*        return( -1 ); */
    }

    /*At this point, all files should be open*/
    printf("myrank: %d - output file %s is open\n",*myrank,coutput);

    done = 0;
    while ( !done ) {
        if ( *myrank == 0 )
            numread = read( infd, buf, BUFSIZE );
#ifdef __MPI
        MPI_Bcast( &numread, 1, MPI_INT, 0, *npcopy_comm );
#endif
        if ( numread > 0 ) {
#ifdef __MPI
            MPI_Bcast( buf, numread, MPI_BYTE, 0, *npcopy_comm );
#endif
            if (*myrank == *jwrite){
             write( outfd, buf, numread );
             printf("myid: %d procid: %d - I have written a chunk %d \n",*myrank,getpid(),numread);
            }
        }
        else {
            close( outfd );
            done = 1;
        }
    }

#ifdef __MPI
/*   MPI_Finalize(); */
#endif

    return 0;

} 

int F77NAME(portlib_parcopy_)(npcopy_comm,myrank,cinput,coutput,ctarg)
    int *npcopy_comm;
    int *myrank;
    const char *cinput;
    const char *coutput;
    const char *ctarg;
{ 
    F77NAME(portlib_parcopy)(npcopy_comm,myrank,cinput,coutput,ctarg);
}

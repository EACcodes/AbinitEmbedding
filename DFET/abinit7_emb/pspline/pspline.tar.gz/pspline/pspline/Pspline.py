#!/usr/bin/env python

"""
$Id: Pspline.py,v 1.2 2009-07-15 17:23:16 Alex_Pletzer Exp $
---------------------------------------------------------------------------
 This code was developed at Tech-X (www.txcorp.com). It is free for any one
 to use but comes with no warranty whatsoever. Use at your own risk. 
 Thanks for reporting bugs to pletzer@txcorp.com. 
---------------------------------------------------------------------------
"""

import numpy
from ctypes import CDLL, POINTER, c_int, c_double, c_float, byref, \
     c_int, RTLD_GLOBAL, RTLD_LOCAL


class Pspline:
    """
    1D, 2D, 3D spline, Akima, or linear interpolation
    """

    def __init__(self, sharedObject, numUnderscores=1):
        """
        Constructor
        @param sharedObject path to pspline/TranspNumeric shared object
        @param numUnderscores number of trailing underscores in symbol table
        """
        self.isReady = False
        self.isAllocated = False

        # opaque type holder
        self.holder = numpy.array([0]*12)
        self.handle = self.holder.ctypes.data_as(POINTER(c_int))
        self.object = CDLL(sharedObject, mode=RTLD_GLOBAL)
        self.underscore = '_' * numUnderscores
        self.ier = c_int()
        self.bcTypes = []
        self.bcVals  = []
        self.numDims = 0  # 1, 2, or 3
        self.type    = '' # r4 or r8
        self.cType   = ''
        self.nType   = ''

    def __del__(self):
        """
        Destructor
        """
        if self.isAllocated:
            meth = 'self.object.czspline_free%d_%s%s' % \
                (self.numDims, self.type, self.underscore)
            args = '(self.handle, byref(self.ier))'
            eval(meth + args)
            assert(self.ier.value == 0)
        

    def setup(self, axes, functValues, boundTypes=[], boundValues=[]):
        """
        Allocate object and compute spline coefficients
        @param axes list of ndim axes [x1, x2, ...]
        @param functValues array of function values, *varies fastest along x1*
        @param boundTypes list of ndim tuples [(bc0, bc1), ...]
                          (-1 for periodic, 0 for not-a-knot ,...)
        @param boundValues list of ndim tuples [(bv0, bv1), ...]
                           only used if bc0, ... are > 0
        
        """
        self.numDims = len(axes)
        assert(len(functValues.shape) == self.numDims)

        if functValues.dtype == numpy.float32:
            self.type = 'r4'
            self.cType = 'c_float'
            self.nType = numpy.float32
        elif functValues.dtype == numpy.float64:
            self.type = 'r8'
            self.cType = 'c_double'
            self.nType = numpy.float64
        else:
            raise TypeError, 'functValues must be float32/float64, got ', \
                functValues.dtype
        
        if boundTypes:
            assert(len(boundTypes) == self.numDims)
            self.bcTypes = boundTypes
        else:
            # defaults to not-a-knot
            self.bcTypes = [ (0,0,) for idim in range(self.ndims) ]

        if boundValues:
            assert(len(boundValues) == self.numDims)
            self.bcVals = boundValues
        for idim in range(self.numDims):
            # order of axes is x3, x2, x1 in functValues
            n = functValues.shape[self.numDims-idim-1]
            assert(n == len(axes[idim]))

        # initialize
        meth = 'self.object.czspline_init%d_%s%s' % \
            (self.numDims, self.type, self.underscore)
        args = '(self.handle'
        for idim in range(self.numDims):
            # order of axes is x3, x2, x1 in functValues
            n = functValues.shape[self.numDims-idim-1]
            args += ', byref(c_int(%d))' % n
        for idim in range(self.numDims):
            args += ',  self.bcTypes[%d].ctypes.data_as(POINTER(c_int))' \
                % idim
        args += ', byref(self.ier))'
        eval(meth + args)
        assert(self.ier.value == 0)
        
        self.isAllocated = True

        # set axes
        meth = 'self.object.czspline_set_axes%d_%s%s' % \
            (self.numDims, self.type, self.underscore)
        args = '(self.handle'
        for idim in range(self.numDims):
            # order of axes is x3, x2, x1 in functValues
            n = functValues.shape[self.numDims-idim-1]
            args += ', byref(c_int(%d))' % n
        for idim in range(self.numDims):
            args += ', axes[%s].ctypes.data_as(POINTER(%s))' \
                % (idim, self.cType)
        args += ', byref(self.ier))'
        eval(meth + args)
        assert(self.ier.value == 0)
        
        # setup
        meth = 'self.object.czspline_setup%d_%s%s' % \
            (self.numDims, self.type, self.underscore)
        args = '(self.handle'
        for idim in range(self.numDims):
            # order of axes is x3, x2, x1 in functValues
            n = functValues.shape[self.numDims-idim-1]
            args += ', byref(c_int(%d))' % n
        args += ', functValues.ctypes.data_as(POINTER(%s)), byref(self.ier))' \
            % self.cType
        eval(meth + args)
        assert(self.ier.value == 0)

        self.isReady = True

    def getPointInterp(self, pt):
        """
        Interpolation at a single point
        @param pt coordinate point (x1, x2, ...)
        @return interpolated value
        """
        assert(self.isReady)

        fIntrp = eval(self.cType + '()')
        meth = 'self.object.czspline_interp%d_%s%s' % \
            (self.numDims, self.type, self.underscore)
        args = '(self.handle'
        for idim in range(self.numDims):
            args += ', byref(%s(pt[%d]))' % (self.cType, idim)
        args += ', byref(fIntrp), byref(self.ier))'
        eval(meth + args)
        assert(self.ier.value == 0)

        return fIntrp.value

    def getCloudInterp(self, pts):
        """
        Interpolation at arbitrary points
        @param pts list of [x1, x2, ...] points with len(x1)==len(x2)==..
        @return interpolated values
        """
        sz = len(pts[0])
        for idim in range(self.numDims):
            assert(len(pts[idim]) == sz)

        fIntrp = numpy.zeros( (sz,), self.nType)
        meth = 'self.object.czspline_interp%d_cloud_%s%s' % \
            (self.numDims, self.type, self.underscore)
        csz = c_int(sz)
        args = '(self.handle, byref(csz)'
        for idim in range(self.numDims):
            args += ', pts[%d].ctypes.data_as(POINTER(%s))' \
                % (idim, self.cType)
        args += ', fIntrp.ctypes.data_as(POINTER(%s)), byref(self.ier))' \
            % self.cType
        eval(meth + args)
        assert(self.ier.value == 0)

        return fIntrp

    def getArrayInterp(self, pts):
        """
        Interpolation on a structured grid
        @param pts list of [x1, x2, ...] points
        @return interpolated values x1 cross x2 cross ...
        """
        ndims = len(pts)
        assert(ndims == self.numDims)

        dims = '('
        # dimension order is reversed
        for idim in range(ndims-1, -1, -1):
            dims += '%d,' % len(pts[idim])
        dims += ')'
        fIntrp = eval('numpy.zeros(%s, self.nType)' % dims)
        meth = 'self.object.czspline_interp%d_array_%s%s' % \
            (self.numDims, self.type, self.underscore)
        args = '(self.handle'
        for idim in range(self.numDims):
            args += ', byref(c_int(%d))' % len(pts[idim])
        for idim in range(self.numDims):
            args += ', pts[%d].ctypes.data_as(POINTER(%s))' \
                % (idim, self.cType)
        args += ', fIntrp.ctypes.data_as(POINTER(%s)), byref(self.ier))' \
            % self.cType
        eval(meth + args)
        assert(self.ier.value == 0)

        return fIntrp

        
##############################################################

def f3(z): return z**3
def f2(y): return y**3
def f1(x): return numpy.cos(2*numpy.pi*(x-0.2443))

def test(libdir, sharedObject):

    so = libdir + sharedObject

    MAXERROR = 1.e-8

    nx1, nx2, nx3 = 11, 21, 31
    x1min, x1max = 0., 1.
    x2min, x2max = 0., 2.
    x3min, x3max = 0., 3.
    dx1 = (x1max - x1min) / float(nx1-1)
    dx2 = (x2max - x2min) / float(nx2-1)
    dx3 = (x3max - x3min) / float(nx3-1)
    x1 = x1min + dx1 * numpy.arange(0, nx1)
    x2 = x2min + dx2 * numpy.arange(0, nx2)
    x3 = x3min + dx3 * numpy.arange(0, nx3)
    f = numpy.zeros( (nx3,), numpy.float64 )
    ff = numpy.zeros( (nx3, nx2,), numpy.float64 )
    fff = numpy.zeros( (nx3, nx2, nx1,), numpy.float64 )
    for k in range(nx3):
        z = x3[k]
        f[k] = f3(z)
        for j in range(nx2):
            y = x2[j]
            ff[k, j] = f2(y) * f3(z)
            for i in range(nx1):
                x = x1[i]
                fff[k, j, i] = f1(x) * f2(y) * f3(z)


    bc1 = numpy.array([-1]*2) # periodic
    bc2 = numpy.array([0]*2)  # not-a-knot
    bc3 = numpy.array([0]*2)  # not-a-knot

    #
    # 1d test
    #
    ps1 = Pspline(so)
    ps1.setup(axes=[x3,], functValues=f, boundTypes=[bc3,])

    z = 1.5
    print ps1.getPointInterp( (z,) )
    assert( abs(ps1.getPointInterp( (z,) ) - f3(z)) < MAXERROR )

    zs = numpy.array([0.5, 1.0, 2.0], numpy.float64)
    print ps1.getCloudInterp([zs,])
    assert( abs(ps1.getArrayInterp([zs,]) - f3(zs)).any() < MAXERROR )

    # should be the same as cloud interpolation in 1D
    print ps1.getArrayInterp([zs,])
    assert( abs(ps1.getArrayInterp([zs,]) - f3(zs)).any() < MAXERROR )

    #
    # 2d test
    #
    ps2 = Pspline(so)
    ps2.setup(axes=[x2, x3,], functValues=ff, boundTypes=[bc2, bc3,])

    y, z = 1.0, 1.5
    print ps2.getPointInterp( (y, z,) )
    assert( abs(ps2.getPointInterp( (y, z,) ) - f2(y)*f3(z)) < MAXERROR )

    ys = numpy.array([0.3, 0.7, 1.5], numpy.float64)
    zs = numpy.array([0.5, 1.0, 2.0], numpy.float64)
    print ps2.getCloudInterp([ys, zs,])
    assert( abs(ps2.getCloudInterp([ys, zs,]) - f2(ys)*f3(zs)).all() < MAXERROR )

    print ps2.getArrayInterp([ys, zs,])
    print numpy.outer(f3(zs), f2(ys))
    assert( abs(ps2.getArrayInterp([ys, zs,]) - numpy.outer(f3(zs), f2(ys))).all() < MAXERROR )
   
    #
    # 3d test
    #
    ps3 = Pspline(so)
    ps3.setup(axes=[x1, x2, x3,], functValues=fff, boundTypes=[bc1, bc2, bc3,])

    x, y, z = 0.5, 1.0, 1.5
    print ps3.getPointInterp( (x, y, z,) )
    assert( abs(ps3.getPointInterp( (x, y, z,) ) - f1(x)*f2(y)*f3(z)) < MAXERROR )

    xs = numpy.array([0.1, 0.4, 0.8], numpy.float64)
    ys = numpy.array([0.3, 0.7, 1.5], numpy.float64)
    zs = numpy.array([0.5, 1.0, 2.0], numpy.float64)
    print ps3.getCloudInterp([xs, ys, zs,])
    assert( abs(ps3.getCloudInterp([xs, ys, zs,]) - f1(xs)*f2(ys)*f3(zs)).all() < MAXERROR )

    print ps3.getArrayInterp([xs, ys, zs,])
    ff3 = numpy.multiply.outer( f3(zs), numpy.ones((len(ys), len(xs),), numpy.float64) )
    ff2 = numpy.multiply.outer( numpy.outer( numpy.ones((len(zs),), numpy.float64), f2(ys) ), \
                                    numpy.ones((len(xs),), numpy.float64) )
    ff1 = numpy.multiply.outer( numpy.ones((len(zs), len(ys),), numpy.float64), f1(xs) )
    assert( abs(ps3.getArrayInterp([xs, ys, zs,]) - ff3*ff2*ff1).all() < MAXERROR )
   

if __name__ == '__main__': 
    import sys
    import optparse
    parser = optparse.OptionParser()
    parser.add_option('-l', '--libdir', action='store', type='string',
                      dest='libdir', help='directory where shared library exists',
                      default='/usr/local/lib')
    parser.add_option('-s', '--shared', action='store', type='string',
                      dest='sharedObject', help='location of shared object',
                      default='libTranspNumeric.so')
    options, args = parser.parse_args()
    test(options.libdir, options.sharedObject)
    
